﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cameraController : MonoBehaviour
{
    public GameObject player;

    private Vector3 offset;

    void Start()
    {
        //setting the variable offset to the object this code is connected to and setting it to transform position subtract the players transform position
        offset = transform.position - player.transform.position;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        //now set my offset position to be the same as the players transform position plus the offset.
        transform.position = player.transform.position + offset;
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rotator : MonoBehaviour
{
   
    void Update()
    {
        //this makes the object rotate automaticly
        transform.Rotate(new Vector3(15, 30, 45) * Time.deltaTime);
    }
}
